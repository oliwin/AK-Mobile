@if(isset($path))
<div class="row">
  <div class="col-md-12" id="actions-block">
      <a class="btn btn-success" href="{{$path}}">Create +</a>
    </div>
</div>
@endif

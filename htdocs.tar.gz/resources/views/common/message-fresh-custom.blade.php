<div class="note custom-flesh-message">
    <h4 class="block title"></h4>
    <a href="#" class="close">×</a>
    <ul class="bd">
        <li></li>
    </ul>
</div>

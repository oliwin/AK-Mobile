<div class="note note-info">
    <h4 class="block">{{ trans('index.no_results') }}</h4>
    <p>{{ trans('index.no_results_text') }}</p>
</div>
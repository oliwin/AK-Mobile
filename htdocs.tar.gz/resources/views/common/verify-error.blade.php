<div class="note note-warning">
    <h4 class="block">{{ trans('index.activate_account') }}</h4>
    <a href="#" class="close">&times;</a>{{ trans('index.please') }}, <a href="{{ url('/activation') }}">{{ trans('index.activate') }}</a> {{ trans('index.activate_account_text') }}
</div>

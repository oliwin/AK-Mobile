<?php $__env->startSection('content'); ?>
<div class="block-form">
   <fieldset>
      <legend>Edit prototype <a class="back-link" href="<?php echo e(URL::previous()); ?>">Back</a>
      </legend>
      <div class="row">
         <?php echo e(Form::model($prototype, array('route' => array('prototypes.update', $prototype['_id']), 'files' => false, 'method' => 'PUT'))); ?>

         <div class="form-group">
            <label class="col-md-12 control-label">Name <span class="required-field">*</span></label>
            <div class="col-md-12">
               <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => "Name"]); ?>

            </div>
         </div>
         <div class="form-group">
            <label class="col-md-12 control-label">Available</label>
            <div class="col-md-3">
               <?=Form::checkbox('available', 1, ($prototype["available"] == "1"));?>
            </div>
         </div>
         <div class="clearfix"></div>
         <div class="form-group prototype-list">
            <div class="col-md-12">
               <?php if(count($fields) > 0): ?>
                  <h4>Parameters</h4>
                  <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="row item">
                        <div class="col-md-11">
                           <span><?php echo e($v["name"]); ?></span>
                           <p style="font-size: 11px; color: #666"><?php if($v["type"] == "2"): ?> Object <?php elseif($v["type"] == 3): ?> Array <?php else: ?> Scalar <?php endif; ?></p>
                        </div>
                        <div class="col-md-1"><?php echo e(Form::checkbox('parameters[]', App\Helpers\Helper::getMongoIDString($v["_id"]))); ?></div>
                     </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
            </div>
         </div>
         <div class="form-group">
            <div class="col-lg-12">
               <button type="submit" class="btn btn-primary">Update</button>
            </div>
         </div>
         <?php echo Form::close(); ?>

      </div>
</fieldset>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
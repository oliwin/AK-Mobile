<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="keywords" content="">
      <link rel="Shortcut Icon" href="http://snipethetrade.com/wp-content/themes/snipthetrade/img/favicon.ico"
         type="image/x-icon">
      <meta name="format-detection" content="telephone=no">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="viewport"
         content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no, minimal-ui">
      <title>Admin Panel - Game</title>
      <!-- Scripts-->
      <script
         src="https://code.jquery.com/jquery-3.1.1.js"
         integrity="sha256-16cdPddA6VdVInumRGo6IbivbERE8p7CQR3HzTBuELA="
         crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
         integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
         crossorigin="anonymous"></script>
      <script src="<?php echo e(URL::asset('js/custom.js')); ?>"></script>
      <!-- CSS -->
      <link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(URL::asset('css/custom.css')); ?>" rel="stylesheet">
   </head>
   <body>
      <?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="container target" id="main-container">
         <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="panel">
               <div class="panel-heading">
                  <h3 class="panel-title">Menu</h3>
               </div>
               <div class="panel-body">
                  <a class="<?php echo e((Request::is('objects') || Request::is('objects/*') ? 'active' : '')); ?> list-group-item"
                     href="<?php echo e(url('objects')); ?>">Objects</a>
                  <a class="<?php echo e((Request::is('prototypes') || Request::is('prototypes/*') ? 'active' : '')); ?> list-group-item"
                     href="<?php echo e(url('prototypes')); ?>">Prototypes</a>
                  <a class="<?php echo e((Request::is('fields') || Request::is('fields/*') ? 'active' : '')); ?> list-group-item"
                     href="<?php echo e(url('fields')); ?>">Parameters</a>
                  <a class="<?php echo e((Request::is('categories') || Request::is('categories/*') ? 'active' : '')); ?> list-group-item"
                     href="<?php echo e(url('categories')); ?>">Categories</a>
               </div>
            </div>

            <div class="panel">
               <div class="panel-heading">
                  <h3 class="panel-title">System</h3>
               </div>
               <div class="panel-body profile-block">
                  <?php if(Auth::check()): ?>
                        <ul role="menu">
                           <li><span class="name"><?php echo e(Auth::user()->name); ?></span></li>
                           <li><a href="#" onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                 <i class="glyphicon glyphicon-log-out"></i></a></li>
                        </ul>

                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST"
                              style="display: none;">
                           <?php echo e(csrf_field()); ?>

                        </form>
                  <?php endif; ?>
                  </div>
               </div>

         </div>

         <div class="col-sm-9">
            <div id="content">
               <?php echo $__env->make('common.messages-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               <?php echo $__env->make('common.messages-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               <?php echo $__env->yieldContent('content'); ?>
            </div>
         </div>
         <?php echo $__env->make("common.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <!-- #### Developed by Oleg Ponomarchuk | ponomarchukov@gmail.com ########## -->
   </body>
</html>

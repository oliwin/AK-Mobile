<div id="search" class="row">
  <?php echo e(Form::open(array('url' => $search_path, 'class' => 'form-inline', 'method' => 'GET'))); ?>

    <div class="col-md-2" style="width: 70px !important;">
      <?php echo e(Form::text('_id', null, array("placeholder" => "ID", "class" => "form-control"))); ?>

    </div>
    <div class="col-md-2">
      <?php echo e(Form::text('name', null, array("placeholder" => "Name\Prefix", "class" => "form-control"))); ?>

    </div>
    <?php if(isset($categories)): ?>
      <div class="col-md-2">
        <?php echo e(Form::select('category_id', $categories, null, array("class" => "form-control"))); ?>

      </div>
    <?php endif; ?>
    <?php if(isset($prototypes)): ?>
    <div class="col-md-3">
      <?php echo e(Form::select('prototype_id', \App\Helpers\Helper::reformatArrayToList($prototypes), null, array("class" => "form-control"))); ?>

    </div>
    <?php endif; ?>
    <div class="col-md-2">
      <?php echo e(Form::select('available', ["0" => "Status", "1" => "Available", "2" => "Not available"], null, array("class" => "form-control"))); ?>

    </div>

    <div class="col-md-1">
      <input type="submit" name="search" value="Go" class="btn btn-success">
    </div>
  <?php echo e(Form::close()); ?>

</div>

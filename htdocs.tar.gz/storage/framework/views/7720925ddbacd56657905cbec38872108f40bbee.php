<div class="control-group">
    <div class="col-md-12">
        <?php if(count($parameters) > 0): ?>
            <h4>Parameters</h4>
            <ul class="parameters-list">
                <?php $__currentLoopData = $parameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <!-- If array with some values -->

                        <label><?php echo e($parameter["name"]); ?></label><span class="help-block">(Scalar)</span>

                        <?php if($parameter["type"] == "3"): ?>
                            <ul class="parameters-list-array">
                                <p class="help-block">(Array)</p>

                                <?php $__currentLoopData = $parameter["value"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ak => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <input class="form-control" type="text" name="parameters_array[<?php echo e((string)$parameter["_id"]); ?>][]"
                                               value="<?php echo e($v); ?>">
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            <!-- If another -->
                        <?php else: ?>

                            <input class="form-control" type="hidden" name="parameters[]"
                                   value="<?php echo e((string)$parameter["_id"]); ?>">

                            <input class="form-control" type="hidden" name="children[]"
                                   value="">

                            <input type="text" class="form-control" name="values[]" value="<?php echo e($parameter["value"]); ?>">

                            <?php echo $__env->make('field.parameter', ["parameter" => $parameter], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <?php else: ?>
            <p class="no-rows">There are not parameters in prototype</p>
        <?php endif; ?>
    </div>
</div>
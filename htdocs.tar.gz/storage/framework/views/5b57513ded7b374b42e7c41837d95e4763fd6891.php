<!-- BEGIN FOOTER -->
<div class="clearfix"></div>
<div class="col-md-12" id="footer">
    <div class="page-footer-inner">
        <?=date("Y")?> &copy; Admin Panel - Game
    </div>
</div>
<!-- END FOOTER -->

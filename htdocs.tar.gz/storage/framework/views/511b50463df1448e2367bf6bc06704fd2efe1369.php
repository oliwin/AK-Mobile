<?php $__env->startSection('content'); ?>
    <div class="block-form">
        <fieldset>
            <legend>Edit parameter <a class="back-link" href="<?php echo e(URL::previous()); ?>">Back</a>
            </legend>
            <div class="row">
                <?php echo e(Form::model($field, array('route' => array('fields.update', $field['_id']), 'files' => false, 'method' => 'PUT'))); ?>

                <div class="form-group">
                    <label class="col-md-12 control-label">Name <span class="required-field">*</span></label>
                    <div class="col-md-12">
                        <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => "Name"]); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-12 control-label">Default value <span class="required-field">*</span></label>
                    <div class="col-md-3">
                        <?php echo Form::text('default', null, ['class' => 'form-control', 'required' => 'required', 'id' => "default_value", 'placeholder' => "Default Value"]); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-12 control-label">Available</label>
                    <div class="col-md-3">
                        <?=Form::checkbox('available', 1, ($field["available"] == "1"));?>
                    </div>
                </div>
                <!--<div class="form-group">
                    <label class="col-md-12 control-label">Visibility</label>
                    <div class="col-md-3">
                        <?=Form::selectRange('visibility', 0, 20)?>
                    </div>
                </div>-->
                <div class="form-group">
                    <label class="col-md-12 control-label">Only numbers</label>
                    <div class="col-md-3">
                        <?=Form::checkbox('only_numbers');?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-12 control-label">Type <span class="required-field">*</span></label>
                    <div class="col-md-3 select-parameter-type">
                        <?php echo e(Form::select('type', \App\Helpers\Helper::parameterTypes(), $field["type"], array("class" => "form-control"))); ?>

                    </div>
                </div>

                <?php echo $__env->make("field.list-parameters", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>

        </fieldset>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="block-form">
   <fieldset>
      <legend>Create prototype <a class="back-link" href="<?php echo e(URL::previous()); ?>">Back</a>
      </legend>
      <div class="row">
         <?=Form::open(array('route' => 'prototypes.store', 'novalidate' => "novalidate", 'method' => 'POST', 'files' => true))?>
         <div class="form-group">
            <label class="col-md-12 control-label">Name <span class="required-field">*</span></label>
            <div class="col-md-12">
               <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => "Name"]); ?>

            </div>
         </div>
         <div class="form-group">
            <label class="col-md-12 control-label">Available</label>
            <div class="col-md-12">
               <?=Form::checkbox('available', 1, TRUE);?>
            </div>
         </div>
         <div class="form-group">
            <div class="col-md-12 prototype-list">
               <?php if(count($fields) > 0): ?>
               <h4>Parameters <!--<span class="help-block">fields with visibility = 1</span>--></h4>
               <div class="body">
                  <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row item">
                     <div class="col-md-11">
                        <span><?php echo e($v["name"]); ?></span>
                     </div>
                     <div class="col-md-1"><?php echo e(Form::checkbox('parameters[]', App\Helpers\Helper::getMongoIDString($v["_id"]))); ?></div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
               <?php endif; ?>
            </div>
         </div>
         <div class="form-group">
            <div class="col-lg-12">
               <button type="submit" class="btn btn-primary">Add</button>
            </div>
         </div>
         <?php echo Form::close(); ?>

      </div>
</fieldset>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
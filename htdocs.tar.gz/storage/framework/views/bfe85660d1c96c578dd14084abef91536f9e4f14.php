<div class="col-md-12">
    <p>By default is <strong>TRUE</strong>, you can change this above</p>
</div>
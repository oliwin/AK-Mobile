<?php if(isset($path)): ?>
<div class="row">
  <div class="col-md-12" id="actions-block">
      <a class="btn btn-success" href="<?php echo e($path); ?>">Create +</a>
    </div>
</div>
<?php endif; ?>

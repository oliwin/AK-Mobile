<div class="fields-list row">
    <?php echo e(dd($v)); ?>

    <?php $__currentLoopData = $field["value"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4"><?php echo e($v['name']); ?></div>
        <div class="col-md-8">
            <?php echo e(Form::checkbox('field_object['.\App\Helpers\Helper::getMongoIDString($v['_id']).']', $v["default"], array("class" => "form-control"))); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
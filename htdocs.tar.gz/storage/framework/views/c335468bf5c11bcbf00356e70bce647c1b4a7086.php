<?php $__env->startSection('content'); ?>
    <h4>Categories</h4>

    <div id="actions-block">
        <a class="btn btn-success" href="<?php echo e(url("categories/create")); ?>">Create +</a>
    </div>

    <?php if(count($categories)): ?>
        <table class="table">
            <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($field['_id']); ?></th>
                    <td><?php echo e($field['name']); ?></td>
                    <td>
                        <a class="label label-info" href="categories/<?php echo e($field['_id']); ?>/edit">Edit</a>
                        <form action="<?php echo e(URL::route('categories.destroy', $field['_id'])); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="delete label label-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="notification-center">There are not rows</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="block-form">
    <fieldset>
      <legend>Edit object <a class="back-link" href="<?php echo e(URL::previous()); ?>">Back</a>
      </legend>
      <div class="row">
         <?php echo e(Form::model($object, array('route' => array('objects.update', $object['_id']), 'files' => false, 'method' => 'PUT'))); ?>

         <div class="form-group">
            <label class="col-md-12 control-label">Name <span class="required-field">*</span></label>
            <div class="col-md-12">
               <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => "Name"]); ?>

            </div>
         </div>
         <div class="form-group">
            <label class="col-md-12 control-label">Category <span class="required-field">*</span></label>
            <div class="col-md-12">
               <?php echo Form::select("category_id", $categories, null, array("class" => "form-control")); ?>

            </div>
         </div>
         <div class="form-group">
            <label class="col-md-12 control-label">Available</label>
            <div class="col-md-3">
               <?=Form::checkbox('available', 1, ($object["available"] == "1"));?>
            </div>
         </div>
         <div class="form-group prototype-list">

             <div class="col-md-12 row">
                <?php if(count($prototypes)): ?>
                       <label class="col-md-12 control-label">Choose prototype <span class="required-field">*</span></label>
                <?php $__currentLoopData = $prototypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                   <div class="col-md-11">
                      <label><?php echo e($v); ?></label></div>
                      <div class="col-md-1">
                      <?php echo e(Form::radio('prototype_id', $k, FALSE)); ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php else: ?>
                     <p class="no-rows">There are not prototypes</p>
                <?php endif; ?>
          </div>
             </div>
         <div class="form-group fields-list" id="FieldsInPrototype">
           <div class="list"><?php echo $__env->make('object.parameters', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
         </div>
         <div class="form-group">
            <div class="col-md-12">
               <input type="hidden" name="action" value="edit"/>
               <button type="submit" class="btn btn-primary">Update</button>
            </div>
         </div>
         <?php echo Form::close(); ?>

      </div>
    </fieldset>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
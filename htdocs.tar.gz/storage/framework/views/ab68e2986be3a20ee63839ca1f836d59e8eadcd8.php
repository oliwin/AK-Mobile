<div class="control-group content-fields-multi">
    <?php if($field["type"] == "3"): ?>
        <?php $__currentLoopData = $field["value"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <input type="text" name="field_array[]" class="form-control" value="<?php echo e($value); ?>">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php elseif($field["type"] == "2"): ?>

        <div class="fields-list">
            <label class="col-md-12 control-label">Children</label>
            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="col-md-4"><?php echo e($p['name']); ?></div>
                    <div class="col-md-8">
                        <input
                                <?php if(key_exists((string)$p["_id"], $field["children"])): ?> checked <?php endif; ?>
                        type="checkbox"
                                name="parameters[<?php echo e((string)$p['_id']); ?>]"></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
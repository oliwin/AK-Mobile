<?php $__env->startSection('content'); ?>
<?php echo $__env->make('common.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('common.action_buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h4>Parameters</h4>
<?php if(count($fields)): ?>
<table class="table">
   <thead>
      <tr>
         <th>Id</th>
         <th>Name</th>
         <th>Type</th>
         <th>Parent</th>
         <th>Status</th>
         <th>Action</th>
      </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <th><?php echo e($field['_id']); ?></th>
         <td><?php echo e($field['name']); ?></td>
         <td>
            <div class="multi_field"><?php echo e(\App\Helpers\Helper::getTypeParameterName($field['type'])); ?></div>
         </td>
         <td>
            <?php if(!is_null($field['children'])): ?> Child <?php else: ?> Parent <?php endif; ?>
         </td>
         <td><?php if($field['available'] == "1"): ?> <span class="active">Available</span> <?php else: ?> <span class="completed">Not Available</span> <?php endif; ?></td>
         <td>
            <a class="label label-info" href="fields/<?php echo e($field['_id']); ?>/edit">Edit</a>
            <form action="<?php echo e(URL::route('fields.destroy', $field['_id'])); ?>" method="POST">
               <input type="hidden" name="_method" value="DELETE">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <button class="delete label label-danger">Delete</button>
            </form>
         </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>
<?php else: ?>
<p class="notification-center">There are not rows</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
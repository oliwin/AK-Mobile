<label class="col-md-12 control-label">Select children</label>
<div class="fields-list">
    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
            <div class="col-md-4"><?php echo e($v['name']); ?></div>
            <div class="col-md-8"><input type="checkbox" name="parameters[<?php echo e(\App\Helpers\Helper::getMongoIDString($v['_id'])); ?>]" value="<?php echo e($v['default']); ?>"></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
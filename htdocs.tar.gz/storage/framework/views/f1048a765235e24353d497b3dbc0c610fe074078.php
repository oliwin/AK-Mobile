<div class="control-group">


    <div class="col-md-12">
        <!-- Object type -->
        <?php if(isset($parameters[2])): ?>
            <div class="col-md-12">
                <h5>Object</h5>

                <?php $a = 0; ?>

                <?php $__currentLoopData = $parameters[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <label><?php echo e($v["name"]); ?> (Parent)</label>

                    <?php $__currentLoopData = $v["value"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-12">
                            <label><?php echo e($name); ?></label>
                            <input class="input form-control" name="parameters[2][<?php echo e($v["parameter_id"]); ?>]" type="text"
                                   value="<?php echo e($value); ?>"/>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php endif; ?>

    <!-- Scalar type -->

        <?php if(isset($parameters[1])): ?>
            <div class="col-md-12">
                <h5>Scalar</h5>
                <?php $__currentLoopData = $parameters[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row item">
                        <div class="col-md-6">
                            <label><?php echo e($parameter["name"]); ?></label>
                            <input class="input form-control" name="parameters[1][<?php echo e($parameter["parameter_id"]); ?>]"
                                   type="text"
                                   value="<?php echo e($parameter["value"]); ?>"/>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    <!-- Array type -->

        <?php if(isset($parameters[3])): ?>

            <div class="col-md-12">
                <h5>Array</h5>
                <?php $__currentLoopData = $parameters[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $v["value"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kv => $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row item">
                            <div class="col-md-6">
                                <input class="input form-control" name="parameters[3][<?php echo e($v["parameter_id"]); ?>][]"
                                       type="text"
                                       value="<?php echo e($vv); ?>"/>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>


    </div>

</div>
<?php if(count($parameter['children']) > 0): ?>

    <? $parent_id = (string) $parameter["_id"]; ?>

    <ul class="parameters-list-objects">

        <?php $__currentLoopData = $parameter['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php echo $__env->make('field.parameter', $parameter, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <li>
                <label><?php echo e($parameter['name']); ?></label>
                <input class="form-control" type="hidden" name="children[]"
                   value="<?=$parent_id?>">
                <input type="text" class="form-control" name="values[]" value="<?php echo e($parameter["value"]); ?>">

                <input class="form-control" type="hidden" name="parameters[]"
                       value="<?php echo e((string)$parameter["_id"]); ?>">
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
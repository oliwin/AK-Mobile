<?php $__env->startSection('content'); ?>
    <div class="block-form">
        <fieldset>
            <legend>Edit category <a class="back-link" href="<?php echo e(URL::previous()); ?>">Back</a>
            </legend>
            <div class="row">
                <?php echo e(Form::model($category, array('route' => array('categories.update', $category["_id"]), 'files' => false, 'method' => 'PUT'))); ?>

                <div class="form-group">
                    <label class="col-md-12 control-label">Name <span class="required-field">*</span></label>
                    <div class="col-md-12">
                        <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => "Name"]); ?>

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </fieldset>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
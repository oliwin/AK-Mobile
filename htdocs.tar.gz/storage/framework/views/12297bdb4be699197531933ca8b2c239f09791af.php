<?php $__env->startSection('content'); ?>
<?php echo $__env->make('common.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('common.action_buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h4>Objects</h4>
<?php if(count($objects) > 0): ?>
<table class="table">
   <thead>
      <tr>
         <th>Id</th>
         <th>Name</th>
         <th>Category</th>
         <th>Prototype</th>
         <th>Status</th>
         <th>Action</th>
      </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><strong><?php echo e($object['_id']); ?></strong></td>
         <td><?php echo e($object['name']); ?></td>
         <td><?php echo e(\App\Helpers\Helper::inArray($object['category_id'], $categories)); ?></td>
         <td><?php echo e(\App\Helpers\Helper::inArray($object['prototype_id'], \App\Helpers\Helper::reformatArrayToList($prototypes))); ?></td>
         <td><?php if($object['available'] == "1"): ?> <span class="active">Available</span> <?php else: ?> <span class="completed">Not Available</span> <?php endif; ?></td>
         <td>
            <a class="label label-info" href="objects/<?php echo e($object['_id']); ?>/edit">Edit</a>
            <form action="<?php echo e(URL::route('objects.destroy', $object['_id'])); ?>" method="POST">
               <input type="hidden" name="_method" value="DELETE">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <button class="delete label label-danger">Delete</button>
            </form>
            <a class="label label-warning" href="<?php echo e(url("objects/".$object['_id']."/clone")); ?>">Clone</a>
         </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>
<?php else: ?>
<p class="notification-center">There are not rows</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="control-group" id="fields">
    <label class="control-label col-md-12" for="field1">Parameters</label>
    <div class="controls" id="profs">
        <div class="input-append">
            <div class="item-row">
                <div class="col-md-6">
                    <input autocomplete="off" class="input form-control" id="field1" name="field_array[]" type="text"
                           placeholder="Enter value..." data-items="8"/>
                </div>
                <div class="col-md-6">
                    <button id="b1" class="btn add-more" type="button">+</button>
                </div>
            </div>
        </div>
    </div>
</div>
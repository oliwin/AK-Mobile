<?php $__env->startSection('content'); ?>
<div class="block-form">
   <fieldset>
      <legend>Create object <a class="back-link" href="<?php echo e(URL::previous()); ?>">Back</a>
      </legend>
      <div class="row">
         <?=Form::open(array('route' => 'objects.store', 'novalidate' => "novalidate", 'method' => 'POST', 'files' => true))?>
         <div class="form-group">
            <label class="col-md-12 control-label">Name <span class="required-field">*</span></label>
            <div class="col-md-12">
               <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => "Name"]); ?>

            </div>
         </div>
         <div class="form-group">
            <label class="col-md-12 control-label">Category <span class="required-field">*</span></label>
            <div class="col-md-12">
               <?php echo Form::select("category_id", $categories, null, array("class" => "form-control")); ?>

            </div>
         </div>
         <div class="form-group">
            <label class="col-md-12 control-label">Available</label>
            <div class="col-md-3">
               <?=Form::checkbox('available', 1, TRUE);?>
            </div>
         </div>
         <div class="clearfix"></div>
         <div class="form-group prototype-list">
               <?php if(count($prototypes) > 0): ?>
               <label class="col-md-12 control-label">Choose prototype <span class="required-field">*</span></label>
               <?php $__currentLoopData = $prototypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="item">
                  <div class="col-md-11">
                     <label><?php echo e($name); ?></label>
                  </div>
                  <div class="col-md-1">
                     <?php echo e(Form::radio('prototype_id', $key)); ?>

                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <p class="no-rows">There are not prototypes</p>
               <?php endif; ?>
            <div id="FieldsInPrototype">
               <div class="list">
               </div>
            </div>
         </div>
         <div class="form-group">
            <div class="col-lg-12">
               <input type="hidden" name="action" value="add"/>
               <button type="submit" class="btn btn-primary">Add</button>
            </div>
         </div>
         <?php echo Form::close(); ?>

      </div>
</fieldset>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
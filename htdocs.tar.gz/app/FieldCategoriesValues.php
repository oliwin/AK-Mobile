<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FieldCategoriesValues extends Model
{
  public $timestamps = false;

  protected $table = "field_categories_values";
}
